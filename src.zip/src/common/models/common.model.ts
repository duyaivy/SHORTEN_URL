export interface PaginationRequest {
	limit: string;
	page: string;
}
