export enum JWTType {
	ACCESS_TOKEN,
	REFRESH_TOKEN,
}
